package acptTests.auxiliary;

public class DBData {
    public static final String[][] names = {
            {"Moshe", "Mike"},
            {"Reena","Doron"},
            {"Rami", "Rami"}
    };

    public static final String[] studentIDs={"11111111","22222222","33333333","444444444"};

    public static final String[][] users = {
			{"bAdmin", "bPassWord" },
			{"tlv", "abcd1234" },
			{ "green", "house" }
	};

    public static final String[][] students= {
            {"st1", "pass1" },
            {"st2", "pass2" },
            { "st3", "pass3" },
            { "st4", "pass3" },
            { "st5", "pass3" },
            { "st6", "pass3" }
    	};


}





package acptTests.auxiliary;
import java.util.ArrayList;

public class DBRegisteredProjectInfo {
	public int projectId;
    public ArrayList<String> studentList = new ArrayList<String>();
	public String academicAdviser;

}
HANDLING OUR OBJECTS
In the "Project" class there is a function called "tearDown()" which clears our project's database.
We used this in the the given tests by adding it in the tests' tearDown() method.

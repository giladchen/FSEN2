package ProjectImp.ObesrverPattern;

public interface Observer {
    void update();
}

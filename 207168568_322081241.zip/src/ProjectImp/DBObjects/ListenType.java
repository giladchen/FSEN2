package ProjectImp.DBObjects;

public enum ListenType {
    EMAIL, TEXT, BOTH, NONE
}

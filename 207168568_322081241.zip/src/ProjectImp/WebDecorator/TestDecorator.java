package ProjectImp.WebDecorator;

public class TestDecorator {
    public static void main(String[] args) {

    }
}
